<?php
get_header();

the_post();

include( 'template-page.php' );

get_footer();
?>